Combat Sports Dataset subset
Evan Quinn, https://zenodo.org/records/15349809
License: Public Domain, declared by source author.
Three classes: cross, high-guard, kick. Person boxes cropped and resized for classroom image classification.
Fixed group split. Held-out test data are not distributed in this student download.
